let nombre;
//tipo de datos primitivos:
//null

//undefine
//booleam
//numeric
//string
//symbol
//bigint

console.log(typeof(nombre));