
//var, solo se utiliza pat variables globales, 

// var x =1;
// if(x==1){
//     
//     var x=2;
//     console.log(x);
// }
//console.log(x);

//let, variable local.
// let x =2

// if(x==2){
    
//     let x=3;
//     console.log(x); //3
// }

// console.log(x); //2

// let h =3;
// h =2;
// function suma(x) {
   
// }

// //constante, const
// const pi = 3.14
// console.log(pi);

//Hoisting

// console.log(sum)
// var a =2, b=3

// var sum = a+b



function suma() {
    var a =2, b=3
    return a+b;
}

console.log(suma());



